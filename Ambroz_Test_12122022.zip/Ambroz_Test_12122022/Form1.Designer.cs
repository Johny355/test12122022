﻿namespace Ambroz_Test_12122022
{
    partial class Employees
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.insertRec = new System.Windows.Forms.Button();
            this.deleteRec = new System.Windows.Forms.Button();
            this.editRec = new System.Windows.Forms.Button();
            this.countButton = new System.Windows.Forms.Button();
            this.AvgAge = new System.Windows.Forms.Button();
            this.oldest = new System.Windows.Forms.Button();
            this.youngest = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // insertRec
            // 
            this.insertRec.Location = new System.Drawing.Point(12, 12);
            this.insertRec.Name = "insertRec";
            this.insertRec.Size = new System.Drawing.Size(120, 23);
            this.insertRec.TabIndex = 1;
            this.insertRec.Text = "Insert new record";
            this.insertRec.UseVisualStyleBackColor = true;
            this.insertRec.Click += new System.EventHandler(this.button1_Click);
            // 
            // deleteRec
            // 
            this.deleteRec.Location = new System.Drawing.Point(135, 12);
            this.deleteRec.Name = "deleteRec";
            this.deleteRec.Size = new System.Drawing.Size(120, 23);
            this.deleteRec.TabIndex = 2;
            this.deleteRec.Text = "Delete record";
            this.deleteRec.UseVisualStyleBackColor = true;
            // 
            // editRec
            // 
            this.editRec.Location = new System.Drawing.Point(258, 12);
            this.editRec.Name = "editRec";
            this.editRec.Size = new System.Drawing.Size(120, 23);
            this.editRec.TabIndex = 3;
            this.editRec.Text = "Edit record";
            this.editRec.UseVisualStyleBackColor = true;
            // 
            // countButton
            // 
            this.countButton.Location = new System.Drawing.Point(562, 43);
            this.countButton.Name = "countButton";
            this.countButton.Size = new System.Drawing.Size(67, 23);
            this.countButton.TabIndex = 5;
            this.countButton.Text = "Count";
            this.countButton.UseVisualStyleBackColor = true;
            this.countButton.Click += new System.EventHandler(this.button4_Click);
            // 
            // AvgAge
            // 
            this.AvgAge.Location = new System.Drawing.Point(562, 72);
            this.AvgAge.Name = "AvgAge";
            this.AvgAge.Size = new System.Drawing.Size(67, 23);
            this.AvgAge.TabIndex = 6;
            this.AvgAge.Text = "Avg Age";
            this.AvgAge.UseVisualStyleBackColor = true;
            // 
            // oldest
            // 
            this.oldest.Location = new System.Drawing.Point(562, 101);
            this.oldest.Name = "oldest";
            this.oldest.Size = new System.Drawing.Size(67, 23);
            this.oldest.TabIndex = 7;
            this.oldest.Text = "Oldest";
            this.oldest.UseVisualStyleBackColor = true;
            // 
            // youngest
            // 
            this.youngest.Location = new System.Drawing.Point(562, 130);
            this.youngest.Name = "youngest";
            this.youngest.Size = new System.Drawing.Size(67, 23);
            this.youngest.TabIndex = 8;
            this.youngest.Text = "Youngest";
            this.youngest.UseVisualStyleBackColor = true;
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6});
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(12, 41);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(544, 384);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Id";
            this.columnHeader1.Width = 40;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "First name";
            this.columnHeader2.Width = 100;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Last name";
            this.columnHeader3.Width = 100;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Phone";
            this.columnHeader4.Width = 100;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Email";
            this.columnHeader5.Width = 100;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Birth date";
            this.columnHeader6.Width = 100;
            // 
            // Employees
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.ClientSize = new System.Drawing.Size(635, 437);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.youngest);
            this.Controls.Add(this.oldest);
            this.Controls.Add(this.AvgAge);
            this.Controls.Add(this.countButton);
            this.Controls.Add(this.editRec);
            this.Controls.Add(this.deleteRec);
            this.Controls.Add(this.insertRec);
            this.Name = "Employees";
            this.Text = "Employees";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button insertRec;
        private System.Windows.Forms.Button deleteRec;
        private System.Windows.Forms.Button editRec;
        private System.Windows.Forms.Button countButton;
        private System.Windows.Forms.Button AvgAge;
        private System.Windows.Forms.Button oldest;
        private System.Windows.Forms.Button youngest;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
    }
}

