﻿using _12122022_Ambroz_test;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net.Http;

namespace _12122022_Ambroz_Test
{
    public partial class FormMain : Form
    {
        List<Employee> employees;
        SqlRepository sqlRepository = new SqlRepository();
        public FormMain()
        {
            InitializeComponent();
            employees = sqlRepository.GetEmployees();
            RefreshGUI();
        }

        public void RefreshGUI()
        {
            listView1.Items.Clear();

            foreach (Employee employee in employees)
            {

                ListViewItem listViewItem = new ListViewItem(new string[] {
                    employee.FirstName.ToString(),
                    employee.LastName.ToString(),
                    employee.Phone.ToString(),
                    employee.Email.ToString(),
                    employee.Birthdate.ToString("dd.MM.yyyy")
                });
                listView1.Items.Add(listViewItem);


            }
        }

        private void insertButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormAdd formAdd = new FormAdd(null);
            formAdd.Show();
        }

        private void editButton_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                this.Hide();
                FormEdit formEdit = new FormEdit();
                formEdit.Show();
                var selectedRow = listView1.SelectedItems[0];
                var firstname = selectedRow.SubItems[0].Text;
                var lastname = selectedRow.SubItems[1].Text;
                var phone = selectedRow.SubItems[2].Text;
                var email = selectedRow.SubItems[3].Text;
                var birthdate = selectedRow.SubItems[4].Text;
                formEdit.GetData(firstname, lastname, phone, email, birthdate);
            }
            else
            {
                MessageBox.Show("Nebyl vybrát uživatel k editaci");
            }
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Nebyl vybrán uživatel ke smazání");

            }
            else
            {
                var selectedRow = listView1.SelectedItems[0];
                string lastName = selectedRow.SubItems[1].Text;
                sqlRepository.RemoveEmployees(lastName);
                listView1.SelectedItems[0].Remove();
            }
        }

        private void countButton_Click(object sender, EventArgs e)
        {

        }

        private void avgAgeButton_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void youngestButton_Click(object sender, EventArgs e)
        {

        }
    }
}
