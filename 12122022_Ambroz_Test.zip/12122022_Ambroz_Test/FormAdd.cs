﻿using _12122022_Ambroz_test;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _12122022_Ambroz_Test
{
    public partial class FormAdd : Form
    {
        private Employee employee;

        public FormAdd(Employee employee)
        {
            InitializeComponent();
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            FormMain formMain = new FormMain();
            this.Close();
            formMain.Show();
        }

        private void insertButton_Click(object sender, EventArgs e)
        {
            try
            {
                SqlRepository sqlRepository = new SqlRepository();
                employee = new Employee(nameTxt.Text, LnameTxt.Text, phoneTxt.Text, emailTxt.Text, bDayPicker.Value);
                sqlRepository.CreateEmployee(employee);
                FormMain formMain = new FormMain();
                this.Close();
                formMain.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Nelze přidat více uživatelů stejného příjmení! " + ex.Message);
            }
        }
    }
}
