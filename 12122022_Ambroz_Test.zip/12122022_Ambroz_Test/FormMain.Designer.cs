﻿namespace _12122022_Ambroz_Test
{
    partial class FormMain
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.insertButton = new System.Windows.Forms.Button();
            this.editButton = new System.Windows.Forms.Button();
            this.deleteButton = new System.Windows.Forms.Button();
            this.countButton = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.avgAgeButton = new System.Windows.Forms.Button();
            this.oldestButton = new System.Windows.Forms.Button();
            this.youngestButton = new System.Windows.Forms.Button();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // insertButton
            // 
            this.insertButton.Location = new System.Drawing.Point(12, 12);
            this.insertButton.Name = "insertButton";
            this.insertButton.Size = new System.Drawing.Size(126, 23);
            this.insertButton.TabIndex = 0;
            this.insertButton.Text = "Insert new record";
            this.insertButton.UseVisualStyleBackColor = true;
            this.insertButton.Click += new System.EventHandler(this.insertButton_Click);
            // 
            // editButton
            // 
            this.editButton.Location = new System.Drawing.Point(12, 41);
            this.editButton.Name = "editButton";
            this.editButton.Size = new System.Drawing.Size(126, 23);
            this.editButton.TabIndex = 1;
            this.editButton.Text = "Edit record";
            this.editButton.UseVisualStyleBackColor = true;
            this.editButton.Click += new System.EventHandler(this.editButton_Click);
            // 
            // deleteButton
            // 
            this.deleteButton.Location = new System.Drawing.Point(12, 70);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(126, 23);
            this.deleteButton.TabIndex = 2;
            this.deleteButton.Text = "Delete record";
            this.deleteButton.UseVisualStyleBackColor = true;
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // countButton
            // 
            this.countButton.Location = new System.Drawing.Point(713, 12);
            this.countButton.Name = "countButton";
            this.countButton.Size = new System.Drawing.Size(75, 23);
            this.countButton.TabIndex = 3;
            this.countButton.Text = "Count";
            this.countButton.UseVisualStyleBackColor = true;
            this.countButton.Click += new System.EventHandler(this.countButton_Click);
            // 
            // listView1
            // 
            this.listView1.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.listView1.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(144, 12);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(563, 325);
            this.listView1.TabIndex = 4;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // avgAgeButton
            // 
            this.avgAgeButton.Location = new System.Drawing.Point(713, 41);
            this.avgAgeButton.Name = "avgAgeButton";
            this.avgAgeButton.Size = new System.Drawing.Size(75, 23);
            this.avgAgeButton.TabIndex = 5;
            this.avgAgeButton.Text = "Average age";
            this.avgAgeButton.UseVisualStyleBackColor = true;
            this.avgAgeButton.Click += new System.EventHandler(this.avgAgeButton_Click);
            // 
            // oldestButton
            // 
            this.oldestButton.Location = new System.Drawing.Point(713, 70);
            this.oldestButton.Name = "oldestButton";
            this.oldestButton.Size = new System.Drawing.Size(75, 23);
            this.oldestButton.TabIndex = 6;
            this.oldestButton.Text = "Oldest";
            this.oldestButton.UseVisualStyleBackColor = true;
            this.oldestButton.Click += new System.EventHandler(this.button6_Click);
            // 
            // youngestButton
            // 
            this.youngestButton.Location = new System.Drawing.Point(713, 99);
            this.youngestButton.Name = "youngestButton";
            this.youngestButton.Size = new System.Drawing.Size(75, 23);
            this.youngestButton.TabIndex = 7;
            this.youngestButton.Text = "Youngest";
            this.youngestButton.UseVisualStyleBackColor = true;
            this.youngestButton.Click += new System.EventHandler(this.youngestButton_Click);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "First name";
            this.columnHeader1.Width = 80;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Last name";
            this.columnHeader2.Width = 80;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Phone";
            this.columnHeader3.Width = 100;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Email";
            this.columnHeader4.Width = 150;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Birth date";
            this.columnHeader5.Width = 100;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.ClientSize = new System.Drawing.Size(800, 346);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.youngestButton);
            this.Controls.Add(this.oldestButton);
            this.Controls.Add(this.avgAgeButton);
            this.Controls.Add(this.countButton);
            this.Controls.Add(this.deleteButton);
            this.Controls.Add(this.editButton);
            this.Controls.Add(this.insertButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Employees";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button insertButton;
        private System.Windows.Forms.Button editButton;
        private System.Windows.Forms.Button deleteButton;
        private System.Windows.Forms.Button countButton;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button avgAgeButton;
        private System.Windows.Forms.Button youngestButton;
        private System.Windows.Forms.Button oldestButton;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
    }
}

